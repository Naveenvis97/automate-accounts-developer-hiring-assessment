from fastapi import FastAPI, UploadFile, File, HTTPException
import os
from database import SessionLocal, init_db
from models import ReceiptFile, Receipt
from utils import is_valid_pdf
from ocr import extract_text_from_pdf, parse_receipt_text
from datetime import datetime

app = FastAPI()
init_db()

UPLOAD_DIR = "receipts"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/upload")
def upload_file(file: UploadFile = File(...)):
    db = SessionLocal()
    if not file.filename.endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are allowed.")
    
    file_location = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_location, "wb") as f:
        f.write(file.file.read())

    receipt_file = ReceiptFile(
        file_name=file.filename,
        file_path=file_location,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow()
    )
    db.add(receipt_file)
    db.commit()
    db.refresh(receipt_file)
    return {"file_id": receipt_file.id}

@app.post("/validate")
def validate(file_id: int):
    db = SessionLocal()
    receipt_file = db.query(ReceiptFile).filter(ReceiptFile.id == file_id).first()
    if not receipt_file:
        raise HTTPException(status_code=404, detail="File not found.")

    valid, reason = is_valid_pdf(receipt_file.file_path)
    receipt_file.is_valid = valid
    receipt_file.invalid_reason = reason
    receipt_file.updated_at = datetime.utcnow()
    db.commit()
    return {"is_valid": valid, "reason": reason}

@app.post("/process")
def process(file_id: int):
    db = SessionLocal()
    receipt_file = db.query(ReceiptFile).filter(ReceiptFile.id == file_id).first()
    if not receipt_file or not receipt_file.is_valid:
        raise HTTPException(status_code=400, detail="File is not valid or does not exist.")

    text = extract_text_from_pdf(receipt_file.file_path)
    parsed = parse_receipt_text(text)

    receipt = Receipt(
        purchased_at=parsed["purchased_at"],
        merchant_name=parsed["merchant_name"],
        total_amount=parsed["total_amount"],
        file_path=receipt_file.file_path,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow()
    )
    db.add(receipt)
    receipt_file.is_processed = True
    receipt_file.updated_at = datetime.utcnow()
    db.commit()
    return {"receipt_id": receipt.id}

@app.get("/receipts")
def get_all_receipts():
    db = SessionLocal()
    receipts = db.query(Receipt).all()
    return receipts

@app.get("/receipts/{receipt_id}")
def get_receipt(receipt_id: int):
    db = SessionLocal()
    receipt = db.query(Receipt).filter(Receipt.id == receipt_id).first()
    if not receipt:
        raise HTTPException(status_code=404, detail="Receipt not found.")
    return receipt
