import fitz  # PyMuPDF
import pytesseract

def extract_text_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    text = ""
    for page in doc:
        pix = page.get_pixmap()
        text += pytesseract.image_to_string(pix.tobytes("ppm"))
    return text

def parse_receipt_text(text):
    import re
    merchant_name = text.split("\n")[0].strip()
    date_match = re.search(r'\d{2}/\d{2}/\d{4}', text)
    amount_match = re.search(r'Total:\s*\$?(\d+\.\d{2})', text, re.IGNORECASE)

    return {
        "merchant_name": merchant_name,
        "purchased_at": date_match.group(0) if date_match else None,
        "total_amount": float(amount_match.group(1)) if amount_match else None
    }
