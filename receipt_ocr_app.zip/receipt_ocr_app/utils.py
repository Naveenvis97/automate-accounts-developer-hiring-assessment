import PyPDF2

def is_valid_pdf(file_path):
    try:
        with open(file_path, 'rb') as f:
            PyPDF2.PdfReader(f)
        return True, None
    except Exception as e:
        return False, str(e)
