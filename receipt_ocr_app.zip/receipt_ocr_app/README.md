# Receipt OCR Web Application

## Features

- Upload and validate PDF receipts
- Extract text using OCR (Tesseract)
- Store and retrieve structured receipt data via REST APIs

## Setup

1. Install dependencies:
```
pip install fastapi uvicorn sqlalchemy python-multipart pytesseract PyMuPDF PyPDF2
```

2. Install Tesseract:
- Windows: https://github.com/tesseract-ocr/tesseract
- Linux: `sudo apt install tesseract-ocr`

3. Run the application:
```
uvicorn main:app --reload
```

4. Access the Swagger UI:
```
http://127.0.0.1:8000/docs
```

## Endpoints

- POST `/upload` – Upload receipt PDF
- POST `/validate` – Validate if uploaded file is a PDF
- POST `/process` – Process file with OCR and store extracted data
- GET `/receipts` – Get all receipts
- GET `/receipts/{id}` – Get details of a receipt by ID
